use ic_cdk::export::Principal;
use ic_cdk_macros::{query, update};
use serde::{Deserialize, Serialize};

#[derive(Default, Serialize, Deserialize)]
struct Wallet {
    balance: u64,
}

#[update]
fn send_tokens(receiver: Principal, amount: u64) -> Result<String, String> {
    let mut wallet = STATE.with(|state| state.borrow_mut());
    if wallet.balance < amount {
        return Err("Insufficient balance".to_string());
    }
    wallet.balance -= amount;
    Ok(format!("Sent {} tokens to {:?}", amount, receiver))
}

#[update]
fn receive_tokens(amount: u64) {
    STATE.with(|state| {
        let mut wallet = state.borrow_mut();
        wallet.balance += amount;
    });
}

#[query]
fn get_balance() -> u64 {
    STATE.with(|state| state.borrow().balance)
}

thread_local! {
    static STATE: std::cell::RefCell<Wallet> = std::cell::RefCell::new(Wallet::default());
}