use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct TokenTransfer {
    pub sender: String,
    pub receiver: String,
    pub amount: u64,
}