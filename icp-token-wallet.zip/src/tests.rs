use super::*;

#[test]
fn test_send_tokens() {
    let receiver = Principal::anonymous();

    receive_tokens(100);
    assert_eq!(get_balance(), 100);

    assert!(send_tokens(receiver, 50).is_ok());
    assert_eq!(get_balance(), 50);
}

#[test]
fn test_insufficient_balance() {
    let receiver = Principal::anonymous();

    receive_tokens(20);
    assert!(send_tokens(receiver, 50).is_err());
    assert_eq!(get_balance(), 20);
}